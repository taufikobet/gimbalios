
#import "QLAnalyticEvent.h"

@interface QLAnalyticContentEvent : QLAnalyticEvent

@property (nonatomic, strong) NSString *contentId;

@end
