
#import <Foundation/Foundation.h>

@interface QLTrigger : NSObject

@property (nonatomic, strong) NSString *triggerId;

@end
