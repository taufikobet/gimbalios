
#import <Foundation/Foundation.h>
#import "QLTrigger.h"

@interface QLPlaceTrigger : QLTrigger

- (id)initWithPlaceId:(NSString *)placeId;

@end
